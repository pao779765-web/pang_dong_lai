---
skill_id: ASL-AGENT-001
skill_name: Agent反跑偏管理Skills
version: v1.1-refactor
created_at: 2026-07-02
category: Agent 管理类 Skills
source: Codex/Cursor/Claude 项目返工、网页修复、Bug反馈模板、任务路由、反跑偏边界、长期 AI 调控习惯
target_user: 经常用 Cursor、Codex、Claude、ChatGPT 做项目但遇到乱改、跑偏、失控的人
protection_level: Private Delivery / Core Protocol
---
# version_log

## v1.1-refactor｜2026-07-02

### 重构目标

将原包中跨领域重复的通用执行模板压缩到约 30%，把主要内容重构为 Agent 反跑偏管理专属协议。

### 通用层压缩

删除/压缩：

- 反复展开的“先诊断、再执行、最后自检”；
- 通用五段式输出结构；
- 与 Agent 反跑偏无关的泛化交付话术；
- 多文件重复出现的免责声明长段落。

保留为统一短协议：

1. 先诊断边界，再执行；
2. 能交付 > 稳定 > 体验 > 锦上添花；
3. 先确认真实目标；
4. 不确定信息标注需要人工判断；
5. 输出后短自检。

### 领域层增强

新增/强化：

- Mission Lock / Scope Lock / Context Lock / Change Lock / Acceptance Lock / Rollback Lock；
- L0-L5 改动授权等级；
- 反跑偏 7 门闸流程；
- Context Ledger 上下文账本；
- Change Contract 改动合约；
- Drift Audit Report 跑偏审计报告；
- Minimal Patch Plan 最小补丁方案；
- P0-P4 返工缺陷分级；
- ChatGPT / Claude / Cursor / Codex 工具场景要求；
- 常见翻车案例库；
- Session Handoff 下一轮交接摘要。

### 版本定位

v1.1 不再是泛用 Agent 执行提示词，而是 **Agent 执行控制与反跑偏审计协议**。

## v1.0｜2026-07-02

初始交付版本。

### 来源

Codex/Cursor/Claude 项目返工、网页修复、Bug反馈模板、任务路由、反跑偏边界、长期 AI 调控习惯。

### 初始能力

- 任务路由判断；
- 禁止事项清单；
- 执行边界；
- 最小修改方案；
- 差异摘要；
- 风险提示；
- 回滚建议。
