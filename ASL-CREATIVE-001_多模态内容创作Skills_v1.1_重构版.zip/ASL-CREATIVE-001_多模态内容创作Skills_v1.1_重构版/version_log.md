---
skill_id: ASL-CREATIVE-001
skill_name: 多模态内容创作Skills
version: v1.1-refactor
created_at: 2026-07-02
category: 内容创作类 Skills
source: Sora/Flow 视频创作、军事博物馆配音、图片提示词、分镜、海报、首钢文创、AI 视觉风格控制
target_user: 做短视频、图像、分镜、海报、配音台词、素材规划的人
protection_level: Private Delivery / Core Protocol
---
# version_log

## v1.1-refactor｜2026-07-02

重构目标：将通用模板压缩至约 30%，将多模态内容创作领域专属内容扩展至约 70%。

### 通用层压缩

- 删除跨包重复的长段“朱式底层执行原则”。
- 删除通用五段式输出结构。
- 保留 5 条通用核心协议，并压缩为短模块。
- 减少与内容创作无关的泛化 Agent 工作流话术。

### 领域层增强

- 新增 Creative Brief 创作简报。
- 新增 Shot List 分镜表。
- 新增 Prompt Anatomy 提示词结构。
- 新增视觉一致性 Bible。
- 新增素材缺口表。
- 新增配音时间轴。
- 新增 C0-C6 多模态返工分类。
- 新增真实素材 / AI 生成素材边界。
- 新增版权、历史、素材真实性风险提示。
- 新增展馆、反诈、文创、Skills 宣传等示例调用。

## v1.0｜2026-07-02

初始交付版本。
