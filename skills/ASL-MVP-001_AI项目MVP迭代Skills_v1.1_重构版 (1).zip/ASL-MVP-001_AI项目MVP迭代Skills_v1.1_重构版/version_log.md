---
skill_id: ASL-MVP-001
skill_name: AI项目MVP迭代Skills
version: v1.1-refactor
created_at: 2026-07-02
category: 项目落地类 Skills
source: AI简历体检室、银龄安药AI、AlphaRadar、Skills商店、产品原型、竞赛材料、从想法到网页/小程序的落地讨论
target_user: 有想法但不知道怎么拆 MVP、怎么验证、怎么迭代、怎么上线的人
protection_level: Private Delivery / Core Protocol
---
# version_log

## v1.1-refactor｜2026-07-02

### 重构目标

将原 v1.0 中约 60% 的通用 Agent 执行模板压缩为 30% 左右的通用核心协议，并把主要篇幅改成 AI 项目 MVP 迭代专属方法论。

### 通用层压缩

- 删除多文件重复的“任务诊断 / 执行计划 / 正式输出 / 自检 / 返工建议”五段式。
- 删除重复展开的“先诊断、再执行、不要越界、最后自检”。
- 统一压缩为 5 条通用核心协议。

### 领域层增强

新增/强化：

- MVP 不是低配大产品，而是验证动作；
- 最危险假设识别；
- 用户-痛点-场景切片；
- Core / Trust / Later 范围切割；
- 烟雾测试、礼宾式 MVP、Wizard of Oz、手工交付 MVP；
- 关键行为与假信号区分；
- Demo / MVP / 正式产品边界；
- P0-P5 MVP 跑偏分级；
- 反馈分流与下一轮迭代决策。

### 新增专属交付物

- MVP 验证卡
- MVP 功能切割表
- 原型实现任务单
- 用户反馈分流表
- 下一轮迭代决策单

## v1.0｜2026-07-02

初始交付版本。定位为把模糊项目想法拆成 MVP 范围、用户路径、功能优先级、测试方式、上线计划和复盘规则。
