# Zipline Adapter｜Pipeline / Cost Mapping

## Use when

The task involves event-driven backtesting, Pipeline API, factor screening, commission models, slippage models, or trading calendar assumptions.

## Required mapping

```text
Trading calendar:
Data bundle:
Pipeline/factors:
Commission model:
Slippage model:
Order rules:
Risk controls:
```

## Risk reminders

- Time and calendar semantics must be explicit.
- Commission/slippage models cannot be left implicit for executable claims.
- Factor pipeline results are not automatically tradable signals.
