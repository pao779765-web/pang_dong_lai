# QuantDinger MCP / Agent Gateway Mapping

## Conceptual mapping

| AND task | QuantDinger-style surface |
|---|---|
| Read market data | Read-class Gateway/MCP capability |
| Run backtest | Backtest-class async job |
| Save strategy/indicator | Workspace write capability |
| Paper quick order | Trading-class with explicit confirmation and paper-only default |
| Live execution | Block unless explicit human approval and live gate are both present |

## Safety translation

- Research output stays at research/backtest layer.
- Paper actions require explicit paper context.
- Live actions require a separate gate and must not be inferred from backtest success.

## Handoff prompt

```text
Use the QuantDinger adapter. Preserve Agent Gateway boundaries, scope classes, auditability, paper-only defaults, and human confirmation for live-capable operations. Do not expose secrets or admin token APIs.
```
