# QuantDinger Gateway Smoke Test Checklist

```text
[ ] Health/read-only route can be described without secrets.
[ ] Token/scopes are represented as placeholders only.
[ ] Backtest task is async or explicitly bounded.
[ ] Idempotency is considered for write/backtest/trading-class operations.
[ ] Paper/live distinction is explicit.
[ ] Audit/logging requirement is preserved.
[ ] No admin token API or credential vault is exposed through the adapter.
```
