# QuantDinger Adapter for AND-QUANT-001

## Purpose

This adapter is used when AND-QUANT-001 output needs to be applied to a QuantDinger-style repository or agent workflow.

## Read first

- `.cursor/skills/quantdinger-agent-workflow/SKILL.md` if available.
- `docs/agent/AGENT_ENVIRONMENT_DESIGN.md` if available.
- `docs/agent/AI_INTEGRATION_DESIGN.md` if available.
- `docs/agent/AGENT_QUICKSTART.md` and `docs/agent/agent-openapi.json` if the task touches `/api/agent/v1`.

## Hard boundaries

- Never commit real secrets, production `.env`, API keys, DB passwords, or admin JWT.
- Do not weaken paper-only defaults or live trading gates without explicit human scope.
- Do not add trading/order-placement automation that bypasses human review.
- New agent-facing docs should be English.

## AND handoff fields

```text
Task layer:
Target paths:
Agent Gateway impact:
Scope class impact:
Paper/live impact:
Tests to run:
Human confirmation required:
```
