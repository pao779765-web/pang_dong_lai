# Generic Python Quant Adapter

## Use when

No specific platform is selected, but the user wants Python-based research, data cleaning, indicators, baseline backtests, or experiments.

## Minimum standards

```text
Python version:
Dependencies:
Data source:
Input schema:
Output schema:
Backtest assumptions:
Cost model:
Test command:
```

## Guardrail

Generic Python code should be research/backtest oriented by default. Do not generate real broker/exchange execution without an explicit adapter and permission gate.
