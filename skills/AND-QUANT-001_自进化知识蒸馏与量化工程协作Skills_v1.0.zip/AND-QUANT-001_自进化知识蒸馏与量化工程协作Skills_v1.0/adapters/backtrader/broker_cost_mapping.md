# Backtrader Adapter｜Broker / Commission / Slippage Mapping

## Use when

The task involves Backtrader, Cerebro, broker configuration, strategy classes, commission schemes, slippage, or order execution assumptions.

## Required mapping

```text
Data feed:
Strategy class:
Broker cash:
Commission model:
Slippage model:
Order execution price:
Position sizing:
Analyzer outputs:
```

## Risk reminders

- Do not report a backtest as realistic if commission/slippage are missing.
- Clarify whether orders execute on current close, next open, or broker simulation semantics.
- Track sample period and instrument universe.
