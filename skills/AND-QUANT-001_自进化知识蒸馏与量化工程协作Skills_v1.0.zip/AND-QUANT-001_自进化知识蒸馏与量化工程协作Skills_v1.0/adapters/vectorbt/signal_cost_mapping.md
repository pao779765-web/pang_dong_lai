# VectorBT Adapter｜Signal / Cost Mapping

## Use when

The task involves vectorized backtesting, `Portfolio.from_signals`, parameter sweeps, signal matrices, fees, slippage, or fast research iteration.

## Required mapping

```text
Price array:
Entry signals:
Exit signals:
Fees:
Slippage:
Position sizing:
Parameter grid:
Train/test split:
```

## Risk reminders

- Do not only report the best parameter point.
- Report stability region and sensitivity to fees/slippage.
- Keep signal assumptions explicit.
