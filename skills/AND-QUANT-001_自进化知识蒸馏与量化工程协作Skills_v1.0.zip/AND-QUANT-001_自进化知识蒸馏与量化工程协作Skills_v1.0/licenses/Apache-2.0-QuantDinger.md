# Apache License 2.0 notice for QuantDinger-derived references

QuantDinger public repository materials referenced during this fusion are licensed under Apache License 2.0 according to the source package inspection. If redistributing original or modified QuantDinger files, keep the Apache License and attribution notices.

This AND-QUANT package primarily extracts workflow ideas and adapter notes rather than bundling the full QuantDinger repository.

Official Apache License 2.0 text: https://www.apache.org/licenses/LICENSE-2.0
