"""Generate a simple diff checklist between old and new skill folders."""
from pathlib import Path
import filecmp

OLD = Path('old')
NEW = Path('new')

if not OLD.exists() or not NEW.exists():
    print('Create old/ and new/ folders first.')
    raise SystemExit(0)

old_files = {p.relative_to(OLD) for p in OLD.rglob('*') if p.is_file()}
new_files = {p.relative_to(NEW) for p in NEW.rglob('*') if p.is_file()}

print('# Diff Summary')
print('Added:', sorted(map(str, new_files - old_files)))
print('Removed:', sorted(map(str, old_files - new_files)))
changed = []
for rel in old_files & new_files:
    if not filecmp.cmp(OLD / rel, NEW / rel, shallow=False):
        changed.append(str(rel))
print('Changed:', sorted(changed))
