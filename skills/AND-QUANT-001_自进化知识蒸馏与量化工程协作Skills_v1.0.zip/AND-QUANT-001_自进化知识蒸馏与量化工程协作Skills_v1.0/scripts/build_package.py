"""Build a zip package from the current directory."""
from pathlib import Path
import zipfile

root = Path.cwd()
out = root.parent / f"{root.name}.zip"
ignore = {'.git', '__pycache__'}
with zipfile.ZipFile(out, 'w', zipfile.ZIP_DEFLATED) as z:
    for p in root.rglob('*'):
        if any(part in ignore for part in p.parts):
            continue
        if p.is_file():
            z.write(p, p.relative_to(root.parent))
print(out)
