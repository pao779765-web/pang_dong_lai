"""Fetch upstream source snapshots.

This script is intentionally conservative. It stores metadata and text snapshots,
but should not overwrite stable Skills directly.
"""
from pathlib import Path
from datetime import datetime, timezone
import json

OUT = Path('snapshots')
OUT.mkdir(exist_ok=True)

sources = [
    {"name": "manual-input", "type": "placeholder", "note": "Add video/repo/doc source here."}
]

payload = {
    "created_at": datetime.now(timezone.utc).isoformat(),
    "sources": sources,
    "next_step": "Run scripts/diff_skills.py after adding real sources."
}

(OUT / 'upstream_snapshot.json').write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding='utf-8')
print('snapshot written:', OUT / 'upstream_snapshot.json')
