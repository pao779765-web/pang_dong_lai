"""Minimal smoke checks for AND-QUANT-001."""
from pathlib import Path
import json

root = Path.cwd()
manifest = json.loads((root / 'manifest.json').read_text(encoding='utf-8'))
missing = []
for name, rel in manifest.get('canonical_rule_sources', {}).items():
    if not (root / rel).exists():
        missing.append((name, rel))
if missing:
    raise SystemExit(f'Missing canonical sources: {missing}')

skill = (root / 'SKILL.md').read_text(encoding='utf-8')
for phrase in ['诚实性优先于完整性', '回测结果不是实盘承诺', '权限门禁']:
    assert phrase in skill, phrase
print('smoke tests passed')
