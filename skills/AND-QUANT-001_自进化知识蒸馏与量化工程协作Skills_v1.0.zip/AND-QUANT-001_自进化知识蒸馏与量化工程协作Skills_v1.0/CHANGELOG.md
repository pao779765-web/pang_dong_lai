# Changelog

## 1.0.0｜2026-07-03

### Added

- AND 命名体系：Assimilate → Normalize → Deploy。
- 通用知识蒸馏 + 量化工程闭环的主 SKILL。
- 量化执行协议定义。
- QuantDinger / Backtrader / VectorBT / Zipline / generic-python 适配器结构。
- 因子研究、回测风险、策略反幻觉、权限门禁、版本差异合并器。
- 2–3 天持续更新生命周期。
- 发布前质量检查、风险门禁、反幻觉压测、来源许可证检查。

### Source fusion

- 融合用户个人 Skills 蒸馏思想。
- 融合公开量化工程 Skill 的分层契约、安全边界和验证思想。
- 新增共创的 AND 协议与量化门禁规则。
