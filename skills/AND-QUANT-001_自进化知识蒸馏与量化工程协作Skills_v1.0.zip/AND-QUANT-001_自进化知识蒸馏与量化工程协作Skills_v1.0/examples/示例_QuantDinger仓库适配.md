# 示例｜QuantDinger 仓库适配

## 输入

用户希望把外部量化策略接入 QuantDinger 风格工作流。

## AND 处理

```text
任务层级：backtest / paper
适配器：quantdinger
读取：adapters/quantdinger/AGENTS.md
门禁：不允许默认 live
```

## 交接摘要

```text
目标：将策略思路转为可回测候选
Agent Gateway 影响：可能需要 backtest class，而非 trading class
Scope：R/B 优先，W 需明确，T 默认阻断
测试：运行回测 smoke test，检查 paper/live 分层
```
