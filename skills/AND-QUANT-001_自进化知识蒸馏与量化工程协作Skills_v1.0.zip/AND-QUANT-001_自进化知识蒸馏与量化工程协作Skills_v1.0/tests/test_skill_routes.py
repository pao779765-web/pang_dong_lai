from pathlib import Path

def test_skill_has_core_routes():
    root = Path(__file__).resolve().parents[1]
    text = (root / 'SKILL.md').read_text(encoding='utf-8')
    for phrase in ['量化任务路由', '适配器', '回测与交易成本检查结果']:
        assert phrase in text
