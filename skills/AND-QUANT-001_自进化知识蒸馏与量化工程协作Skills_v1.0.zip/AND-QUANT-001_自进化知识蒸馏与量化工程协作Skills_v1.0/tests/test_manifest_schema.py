import json
from pathlib import Path

def test_manifest_loads():
    root = Path(__file__).resolve().parents[1]
    data = json.loads((root / 'manifest.json').read_text(encoding='utf-8'))
    assert data['id'] == 'AND-QUANT-001'
    assert 'canonical_rule_sources' in data

def test_canonical_sources_exist():
    root = Path(__file__).resolve().parents[1]
    data = json.loads((root / 'manifest.json').read_text(encoding='utf-8'))
    for rel in data['canonical_rule_sources'].values():
        assert (root / rel).exists(), rel
