from pathlib import Path

def test_permission_gate_blocks_live_by_default():
    root = Path(__file__).resolve().parents[1]
    text = (root / 'tools/05_权限与上线门禁.md').read_text(encoding='utf-8')
    assert '默认阻断' in text
    assert 'BLOCK_LIVE' in text
