# AND-QUANT-001 Router

本文件是薄路由层，只告诉 Agent 从哪里开始，不重复主规则。

## Read first

1. `SKILL.md` — 主行为契约。
2. `manifest.json` — 路由、适配器、版本策略。
3. `docs/AND协议定义.md` — AND 的标准动作定义。
4. `docs/量化执行协议定义.md` — 量化研究与工程闭环定义。
5. `tools/04_策略与工具名反幻觉检查器.md` — 外部工具名、策略名、平台名真伪转换。
6. `tools/05_权限与上线门禁.md` — 密钥、账户、实盘、生产环境门禁。

## Routing rules

- 用户要“学习/蒸馏/融合/做成 Skills”时，使用本包主流程。
- 用户要“改具体平台/框架”时，先查 `adapters/`。
- 用户要“实盘/下单/授权/密钥/生产部署”时，先进入 `tools/05_权限与上线门禁.md`。
- 用户只要摘要时，不强制输出完整包，但仍必须区分已确认、推测、未知。

## Language rule

默认中文解释。若任务是直接写入 QuantDinger 风格的 `docs/agent/*` 或 agent-facing repo 文档，则文件内容使用 English，中文只用于对用户说明。
