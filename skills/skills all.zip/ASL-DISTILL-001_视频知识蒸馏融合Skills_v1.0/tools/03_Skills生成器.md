# 03｜Skills 生成器

## 目标

把蒸馏结果生成一个真正可用的 Skills 包，而不是一段总结。

## 标准 Skills 包结构

```text
ASL-XXX-001_名称_v1.0/
├── README.md              # 用途、适用场景、怎么用
├── SKILL.md               # Agent 执行规则
├── manifest.json          # 版本、模块、风险说明
├── codex/
│   ├── AGENTS.md          # 项目级规则
│   └── custom_instruction.txt
├── templates/             # 可复制模板
├── checklists/            # 自检/压测/交付清单
├── examples/              # 示例案例
└── source_notes/          # 来源拆解，不放敏感核心原文
```

## 生成步骤

1. 命名：用 ASL-领域-编号，例如 `ASL-DISTILL-001`。
2. 定义：一句话说清楚这个 Skills 是干嘛的。
3. 触发：用户说什么时应该启用。
4. 输入：需要什么材料。
5. 流程：按步骤写清楚。
6. 输出：规定交付格式。
7. 自检：检查是否跑偏。
8. 反例：列出不能这么做。
9. 版本：写明 v1.0、后续如何迭代。

## 命名规则

| 类型 | 推荐命名 |
|---|---|
| 视频学习/蒸馏 | ASL-DISTILL-001 |
| Agent 防跑偏 | ASL-AGENT-001 |
| 网站落地 | ASL-WEB-001 |
| 学习诊断 | ASL-STUDY-001 |
| 项目 MVP | ASL-MVP-001 |
| 商品化包装 | ASL-COMMERCE-001 |
| 质量压测 | ASL-QA-001 |

## 输出必须避免

- 文件很多但空泛。
- 只写 Prompt，不写输入输出和验收标准。
- 不说明适用边界。
- 不说明风险。
- 不给 Codex 可执行格式。
